// Trocar e-mail em assets/js/config.js
export const FORMS = {
  SEND_TO: "solucoesberger@gmail.com",   // fácil de trocar depois
  PROVIDER: "formsubmit"                 // manter padrão
};